/* Architecture Review Console — core data, state, helpers */
'use strict';

const STORAGE_KEY = 'archReview.workspace.v1';
const LEVELS = ['L1', 'L2', 'L3', 'L4'];
const LEVEL_RANK = { L1: 1, L2: 2, L3: 3, L4: 4 };
const REVIEW_STATES = ['Passed', 'Need Revise', 'Reject'];

const OPTIONS = {
  level: LEVELS,
  status: ['Active', 'Draft', 'Deprecated'],
  changeType: ['—', 'New', 'Modify', 'Deprecated'],
  priority: ['P0 – Critical', 'P1 – High', 'P2 – Medium', 'P3 – Low', '—'],
  lockStatus: ['EXCLUSIVE', 'SHARED', 'LOCKED', 'RETIRED', 'NEW', '-'],
  evaluationResult: REVIEW_STATES,
  experienceLevel: ['High', 'Mid', 'Low', '—']
};

const MEETING = {
  platforms: ['Teams', 'Zoom', 'Feishu', 'On-site', 'Other'],
  statuses: ['Scheduled', 'Completed', 'Cancelled'],
  timezones: ['Asia/Shanghai', 'Asia/Singapore', 'Asia/Tokyo', 'Europe/London', 'Europe/Berlin', 'America/New_York', 'America/Los_Angeles', 'UTC'],
  filter: ['upcoming', 'past', 'all']
};

const GROUP_META = {
  identification: 'IDENTIFICATION',
  governance: 'GOVERNANCE',
  shared: 'SHARED / LOCK',
  audit: 'AUDIT'
};

const COLUMNS = [
  { key: 'level', label: 'Level', group: 'identification', width: 92 },
  { key: 'l1', label: 'L1 Application', group: 'identification', width: 104 },
  { key: 'l2', label: 'L2 Application', group: 'identification', width: 132 },
  { key: 'l3', label: 'L3 Feature / Module', group: 'identification', width: 208 },
  { key: 'l4', label: 'L4 Function Name', group: 'identification', width: 220 },
  { key: 'description', label: 'Description', group: 'identification', width: 248 },
  { key: 'cfcRelated', label: 'CFC Related', group: 'identification', width: 78 },
  { key: 'ownerBizTeam', label: 'Owner Biz Team', group: 'identification', width: 112 },
  { key: 'dtOwner', label: 'DT Owner', group: 'identification', width: 112 },
  { key: 'shadowOwner', label: 'Shadow Owner', group: 'identification', width: 108 },
  { key: 'experienceLevel', label: 'Experience Level', group: 'identification', width: 94 },
  { key: 'techStack', label: 'Tech Stack', group: 'identification', width: 108 },
  { key: 'prdLink', label: 'PRD Link (L3)', group: 'identification', width: 180 },
  { key: 'prdVersion', label: 'PRD Version (Active)', group: 'identification', width: 118 },
  { key: 'changeProject', label: 'Change Project', group: 'identification', width: 150 },
  { key: 'itOwner', label: 'IT Owner', group: 'identification', width: 104 },
  { key: 'fsLink', label: 'FS Link (L4)', group: 'identification', width: 170 },
  { key: 'status', label: 'Status', group: 'governance', width: 86 },
  { key: 'changeType', label: 'Change Type', group: 'governance', width: 92 },
  { key: 'priority', label: 'Priority', group: 'governance', width: 106 },
  { key: 'sharedAcross', label: 'Shared Across (Projects)', group: 'shared', width: 140 },
  { key: 'lockStatus', label: 'Lock Status', group: 'shared', width: 104 },
  { key: 'evaluationResult', label: 'Evaluation Results', group: 'audit', width: 116 },
  { key: 'aiScore', label: 'AI Self Evaluation Score', group: 'audit', width: 108 },
  { key: 'created', label: 'Created', group: 'audit', width: 102 },
  { key: 'lastModified', label: 'Last Modified', group: 'audit', width: 102 },
  { key: 'reviewDate', label: 'Review Date', group: 'audit', width: 102 },
  { key: 'reviewer', label: 'Reviewer', group: 'audit', width: 108 },
  { key: 'notes', label: 'Notes', group: 'audit', width: 200 },
  { key: 'source', label: 'Source', group: 'audit', width: 108 }
];

const DEFAULT_COLUMNS = [
  'level', 'l1', 'l2', 'l3', 'l4', 'prdVersion', 'description',
  'dtOwner', 'status', 'priority', 'lockStatus', 'evaluationResult',
  'aiScore', 'reviewDate'
];

const EXPORT_HEADERS = [
  'RankID', 'Node ID', 'Level', 'L1 Application', 'L2 Application',
  'L3 Feature/module', 'L4 Function Name', 'Description', 'CFC Related',
  'Owner Biz Team', 'DT Owner', 'Shadow Owner', 'Experience Level', 'Tech Stack',
  'PRD Link (L3)', 'PRD Version (Active)', 'Change Project', 'IT Owner', 'FS Link(L4)', 'Status', 'Change Type', 'Priority',
  'Shared Across (Projects)', 'Lock Status', 'Evaluation Results',
  'AI Self Evaluation Score', 'Reviewer', 'Created', 'Last Modified', 'Review Date',
  'Notes', 'Source'
];

const USER = { name: 'Architecture Review Board' };

const ui = {
  view: 'overview',
  search: '',
  filters: {
    level: '', status: '', evaluation: '', priority: '', l1: '', l2: '',
    source: '', lockStatus: '', changeType: ''
  },
  sort: { key: null, dir: 'asc' },
  queueLevel: 'all',
  advanced: false,
  focus: null,
  meetingFilter: 'upcoming'
};

let state = null;
let INDEX = new Map();
let selection = new Set();
let drawerState = null;
let modalState = null;
let draft = null;
let draftDirty = false;
let boardDragId = null;

/* ---------------- Basic helpers ---------------- */
function uid() {
  return 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function esc(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function icon(name, cls) {
  return '<svg class="icon ' + (cls || '') + '" aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
}

function deepCopy(value) {
  return JSON.parse(JSON.stringify(value));
}

function todayISO() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function normalizeNode(raw) {
  const n = Object.assign({}, raw);
  n.id = n.id || n.nodeId || uid();
  n.nodeId = String(n.nodeId || '').trim();
  n.level = String(n.level || '').trim().toUpperCase();
  if (!LEVELS.includes(n.level)) n.level = 'L4';
  n.name = String(n.name || '').trim();
  if (n.evaluationResult) n.evaluationResult = String(n.evaluationResult).trim();
  if (!REVIEW_STATES.includes(n.evaluationResult)) n.evaluationResult = '';
  if (n.aiScore === 0) n.aiScore = 0;
  else if (n.aiScore === '' || n.aiScore == null || isNaN(Number(n.aiScore))) n.aiScore = '';
  else n.aiScore = Math.max(0, Math.min(100, Math.round(Number(n.aiScore))));
  ['description', 'cfcRelated', 'ownerBizTeam', 'dtOwner', 'shadowOwner', 'experienceLevel',
    'techStack', 'prdLink', 'prdVersion', 'changeProject', 'itOwner', 'fsLink', 'status', 'changeType', 'priority',
    'sharedAcross', 'lockStatus', 'created', 'lastModified', 'reviewDate', 'notes',
    'reviewer', 'source'].forEach(k => { n[k] = n[k] == null ? '' : String(n[k]); });
  if (!n.status) n.status = 'Active';
  if (!n.changeType) n.changeType = '—';
  if (!n.priority) n.priority = '—';
  if (!n.lockStatus) n.lockStatus = '-';
  const rank = Number(n.rankId);
  n.rankId = isFinite(rank) && rank > 0 ? rank : null;
  n.parentId = n.parentId || null;
  n.history = Array.isArray(n.history)
    ? n.history.filter(h => h && REVIEW_STATES.includes(h.result)).map(h => ({
        ts: String(h.ts || ''),
        result: h.result,
        reviewer: String(h.reviewer || ''),
        reviewDate: String(h.reviewDate || ''),
        note: String(h.note || ''),
        project: String(h.project || ''),
        version: String(h.version || '')
      }))
    : [];
  if (!n.history.length && REVIEW_STATES.includes(n.evaluationResult)) {
    n.history.push({
      ts: n.reviewDate || n.lastModified || '',
      result: n.evaluationResult,
      reviewer: n.reviewer || '',
      reviewDate: n.reviewDate || '',
      note: '',
      project: n.changeProject || '',
      version: n.prdVersion || ''
    });
  }
  return n;
}

function normalizeMeeting(raw) {
  const m = Object.assign({}, raw);
  m.id = m.id || uid();
  ['title', 'nodeRef', 'date', 'start', 'end', 'timezone', 'platform', 'location',
    'organizer', 'attendees', 'agenda', 'status', 'createdAt', 'updatedAt'].forEach(k => {
    m[k] = m[k] == null ? '' : String(m[k]);
  });
  m.title = m.title.trim();
  m.date = /^\d{4}-\d{2}-\d{2}$/.test(m.date) ? m.date : '';
  m.start = /^\d{2}:\d{2}$/.test(m.start) ? m.start : '';
  m.end = /^\d{2}:\d{2}$/.test(m.end) ? m.end : '';
  if (!MEETING.timezones.includes(m.timezone)) m.timezone = 'Asia/Shanghai';
  if (!MEETING.platforms.includes(m.platform)) m.platform = 'Teams';
  if (!MEETING.statuses.includes(m.status)) m.status = 'Scheduled';
  return m;
}

function addDaysISO(dateStr, days) {
  const d = new Date(String(dateStr) + 'T00:00:00');
  if (isNaN(d.getTime())) return dateStr;
  d.setDate(d.getDate() + days);
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function seedMeetings(nodes) {
  const node = name => nodes.find(n => n.name === name) || null;
  const make = (title, name, offset, start, end, platform, status, attendees, agenda) => {
    const n = node(name);
    return {
      id: 'm' + Math.random().toString(36).slice(2, 9),
      title: title,
      nodeRef: n ? n.id : '',
      date: addDaysISO(todayISO(), offset),
      start: start,
      end: end,
      timezone: 'Asia/Shanghai',
      platform: platform,
      location: platform === 'On-site' ? 'HQ · 12F-03' : 'https://meetings.example.com/' + Math.random().toString(36).slice(2, 8),
      organizer: USER.name,
      attendees: attendees,
      agenda: agenda,
      status: status,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  };
  return [
    make('PRD review — Forecast hierarchy release', 'Manage Forecast Hierarchy', 1, '09:30', '10:30',
      'Teams', 'Scheduled', 'Demand Planning DT, ISG Architecture, Data Platform',
      'Walk through the v1.2 PRD changes, confirm the L4 function scope and agree on the open questions before sign-off.'),
    make('PRD review — Product hierarchy alignment', 'Manage Product Hierarchy', 3, '14:00', '15:00',
      'Feishu', 'Scheduled', 'Product Master DT, ISG Architecture',
      'Align on the shared product hierarchy changes and confirm dependencies with the planning workstream.'),
    make('PRD sign-off — Geo hierarchy', 'Manage Geo Hierarchy', -4, '10:00', '11:00',
      'On-site', 'Completed', 'Demand Planning DT, ISG Architecture',
      'Final walkthrough completed; sign-off recorded in the master list.')
  ].map(normalizeMeeting);
}

function pushReviewHistory(node, note) {
  if (!REVIEW_STATES.includes(node.evaluationResult)) return;
  if (!Array.isArray(node.history)) node.history = [];
  node.history.push({
    ts: new Date().toISOString(),
    result: node.evaluationResult,
    reviewer: node.reviewer || USER.name,
    reviewDate: node.reviewDate || todayISO(),
    note: String(note || '').trim(),
    project: String(node.changeProject || '').trim(),
    version: String(node.prdVersion || '').trim()
  });
}

function defaultState() {
  const seed = deepCopy(window.SEED_DATA || { nodes: [], activity: [] });
  const nodes = seed.nodes.map(normalizeNode);
  return {
    version: 3,
    nodes: nodes,
    activity: (seed.activity || []).map(a => Object.assign({ actor: USER.name }, a)),
    meetings: seedMeetings(nodes),
    settings: {
      visibleColumns: DEFAULT_COLUMNS.slice(),
      collapsed: []
    }
  };
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.nodes) || !parsed.nodes.length) return null;
    parsed.nodes = parsed.nodes.map(normalizeNode);
    parsed.activity = Array.isArray(parsed.activity) ? parsed.activity : [];
    parsed.settings = parsed.settings || {};
    parsed.settings.visibleColumns = Array.isArray(parsed.settings.visibleColumns) && parsed.settings.visibleColumns.length
      ? parsed.settings.visibleColumns.filter(k => COLUMNS.some(c => c.key === k))
      : DEFAULT_COLUMNS.slice();
    if (!parsed.settings.visibleColumns.length) parsed.settings.visibleColumns = DEFAULT_COLUMNS.slice();
    if (!parsed.version || parsed.version < 2) {
      if (!parsed.settings.visibleColumns.includes('prdVersion')) {
        const cols = parsed.settings.visibleColumns.slice();
        const at = cols.indexOf('l4');
        cols.splice(at >= 0 ? at + 1 : cols.length, 0, 'prdVersion');
        parsed.settings.visibleColumns = cols;
      }
      parsed.version = 2;
    }
    parsed.settings.collapsed = Array.isArray(parsed.settings.collapsed) ? parsed.settings.collapsed : [];
    parsed.meetings = Array.isArray(parsed.meetings)
      ? parsed.meetings.map(normalizeMeeting).filter(m => m.title)
      : seedMeetings(parsed.nodes);
    parsed.version = 3;
    return parsed;
  } catch (err) {
    return null;
  }
}

function setSaveState(text, isError) {
  const el = document.getElementById('save-state');
  if (!el) return;
  el.textContent = text;
  el.style.color = isError ? '#fca5a5' : '';
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      version: 3,
      nodes: state.nodes,
      activity: state.activity,
      meetings: state.meetings,
      settings: state.settings
    }));
    const t = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setSaveState('Saved · ' + t);
  } catch (err) {
    setSaveState('Storage unavailable', true);
  }
}

function reindex() {
  INDEX = new Map();
  state.nodes.forEach(n => INDEX.set(n.id, n));
  state.nodes.forEach(n => {
    if (n.parentId && !INDEX.has(n.parentId)) n.parentId = null;
  });
}

function parentOf(n) {
  return n && n.parentId ? INDEX.get(n.parentId) || null : null;
}

function chain(n) {
  const out = [];
  const seen = new Set();
  let cur = n;
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    out.unshift(cur);
    cur = parentOf(cur);
  }
  return out;
}

function nameAtLevel(n, level) {
  const found = chain(n).find(x => x.level === level);
  return found ? found.name : '';
}

function childrenOf(id) {
  return state.nodes.filter(n => n.parentId === id).sort(sortByRank);
}

function hasChildren(id) {
  return state.nodes.some(n => n.parentId === id);
}

function descendantsOf(id) {
  const out = [];
  const walk = pid => {
    state.nodes.filter(n => n.parentId === pid).forEach(n => {
      out.push(n);
      walk(n.id);
    });
  };
  walk(id);
  return out;
}

function sortByRank(a, b) {
  const ra = a.rankId == null ? Number.MAX_SAFE_INTEGER : a.rankId;
  const rb = b.rankId == null ? Number.MAX_SAFE_INTEGER : b.rankId;
  return ra - rb || a.nodeId.localeCompare(b.nodeId);
}

function reviewStatus(n) {
  return REVIEW_STATES.includes(n.evaluationResult) ? n.evaluationResult : 'Pending';
}

function canReview(n) {
  return n.level === 'L3' || n.level === 'L4';
}

function scopeNodes() {
  return state.nodes.filter(canReview);
}

function focusQueueIds() {
  return state.nodes.filter(canReview)
    .filter(n => ui.queueLevel === 'all' || n.level === ui.queueLevel)
    .filter(n => reviewStatus(n) === 'Pending' || reviewStatus(n) === 'Need Revise')
    .sort(queueSort)
    .map(n => n.id);
}

function reviewStats() {
  const scope = scopeNodes();
  const reviewed = scope.filter(n => n.evaluationResult);
  const passed = reviewed.filter(n => n.evaluationResult === 'Passed').length;
  const revise = reviewed.filter(n => n.evaluationResult === 'Need Revise').length;
  const reject = reviewed.filter(n => n.evaluationResult === 'Reject').length;
  const scored = reviewed.filter(n => n.aiScore !== '' && !isNaN(Number(n.aiScore)));
  const avgScore = scored.length
    ? Math.round(scored.reduce((s, n) => s + Number(n.aiScore), 0) / scored.length)
    : null;
  return {
    total: scope.length,
    reviewed: reviewed.length,
    pending: scope.length - reviewed.length,
    passed: passed,
    revise: revise,
    reject: reject,
    attention: revise + reject,
    coverage: scope.length ? Math.round((reviewed.length / scope.length) * 100) : 0,
    passRate: reviewed.length ? Math.round((passed / reviewed.length) * 100) : 0,
    avgScore: avgScore
  };
}

function logActivity(type, node, detail) {
  state.activity.unshift({
    id: uid(),
    type: type,
    ts: new Date().toISOString(),
    nodeId: node ? node.nodeId : '—',
    nodeName: node ? node.name : 'Workspace',
    detail: detail || '',
    actor: USER.name
  });
  if (state.activity.length > 300) state.activity.length = 300;
}

/* ---------------- Formatting ---------------- */
function fmtDate(value) {
  if (!value) return '—';
  const raw = String(value);
  const d = new Date(raw.length === 10 ? raw + 'T00:00:00' : raw);
  if (isNaN(d.getTime())) return raw;
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (isNaN(d.getTime())) return String(value);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) +
    ' · ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function relTime(value) {
  const d = new Date(value);
  if (isNaN(d.getTime())) return fmtDateTime(value);
  const diff = Date.now() - d.getTime();
  const mins = Math.round(diff / 60000);
  if (mins >= 0 && mins < 1) return 'Just now';
  if (mins >= 1 && mins < 60) return mins + ' min ago';
  const hours = Math.round(mins / 60);
  if (hours >= 1 && hours < 24) return hours + 'h ago';
  const days = Math.round(hours / 24);
  if (days >= 1 && days < 7) return days + 'd ago';
  return fmtDate(String(value).slice(0, 10));
}

function initials(name) {
  if (!name) return '—';
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '—';
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

function avatar(name, cls) {
  return '<span class="avatar ' + (cls || '') + '" title="' + esc(name) + '">' + esc(initials(name)) + '</span>';
}

function toast(message, type, detail) {
  const root = document.getElementById('toast-root');
  if (!root) return;
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  const ico = type === 'error' ? 'alert' : type === 'warn' ? 'info' : 'check-circle';
  el.innerHTML = icon(ico) + '<div><strong>' + esc(message) + '</strong>' +
    (detail ? '<small>' + esc(detail) + '</small>' : '') + '</div>';
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 200);
  }, 3600);
  while (root.children.length > 3) root.firstElementChild.remove();
}

function setView(view) {
  ui.view = view;
  if (view !== 'review') ui.focus = null;
  if (location.hash !== '#/' + view) history.replaceState(null, '', '#/' + view);
  render();
  const main = document.querySelector('.content');
  if (main) main.scrollTop = 0;
}

/* ---------------- Filtering ---------------- */
function hasActiveFilters() {
  return Object.keys(ui.filters).some(k => ui.filters[k]) || !!ui.search.trim();
}

function searchText(n) {
  return [
    n.nodeId, n.rankId, n.name, n.description, n.dtOwner, n.ownerBizTeam, n.itOwner,
    n.shadowOwner, n.techStack, n.prdLink, n.fsLink, n.notes, n.reviewer,
    nameAtLevel(n, 'L1'), nameAtLevel(n, 'L2'), nameAtLevel(n, 'L3'), nameAtLevel(n, 'L4')
  ].join(' ').toLowerCase();
}

function matchesFilters(n) {
  const f = ui.filters;
  if (f.level && n.level !== f.level) return false;
  if (f.status && n.status !== f.status) return false;
  if (f.evaluation && reviewStatus(n) !== f.evaluation) return false;
  if (f.priority && n.priority !== f.priority) return false;
  if (f.l1 && nameAtLevel(n, 'L1') !== f.l1) return false;
  if (f.l2 && nameAtLevel(n, 'L2') !== f.l2) return false;
  if (f.source && n.source !== f.source) return false;
  if (f.lockStatus && n.lockStatus !== f.lockStatus) return false;
  if (f.changeType && n.changeType !== f.changeType) return false;
  const q = ui.search.trim().toLowerCase();
  if (q && !searchText(n).includes(q)) return false;
  return true;
}

function filteredNodes() {
  return state.nodes.filter(matchesFilters);
}

function compareNodes(a, b) {
  const key = ui.sort.key;
  const dir = ui.sort.dir === 'desc' ? -1 : 1;
  if (!key) return sortByRank(a, b);
  let av;
  let bv;
  if (key === 'l1' || key === 'l2' || key === 'l3' || key === 'l4') {
    const lvl = key.toUpperCase();
    av = nameAtLevel(a, lvl) || '';
    bv = nameAtLevel(b, lvl) || '';
  } else {
    av = a[key];
    bv = b[key];
  }
  if (key === 'level') { av = LEVEL_RANK[a.level]; bv = LEVEL_RANK[b.level]; }
  if (key === 'evaluationResult') {
    const order = { Pending: 0, 'Need Revise': 1, Reject: 2, Passed: 3 };
    av = order[reviewStatus(a)];
    bv = order[reviewStatus(b)];
  }
  if (key === 'rankId' || key === 'aiScore') {
    av = av === '' || av == null ? -1 : Number(av);
    bv = bv === '' || bv == null ? -1 : Number(bv);
    return (av - bv) * dir;
  }
  av = av == null ? '' : String(av);
  bv = bv == null ? '' : String(bv);
  return av.localeCompare(bv, undefined, { numeric: true }) * dir;
}

function displayRows() {
  const matches = filteredNodes();
  if (ui.sort.key) {
    return matches.sort(compareNodes).map(n => ({ node: n, depth: 0 }));
  }
  if (hasActiveFilters()) {
    return matches.sort(sortByRank).map(n => ({ node: n, depth: 0 }));
  }
  const collapsed = new Set(state.settings.collapsed);
  const out = [];
  const seen = new Set();
  const walk = (n, depth) => {
    if (seen.has(n.id)) return;
    seen.add(n.id);
    out.push({ node: n, depth: depth });
    if (!collapsed.has(n.id)) childrenOf(n.id).forEach(c => walk(c, depth + 1));
  };
  state.nodes.filter(n => !n.parentId).sort(sortByRank).forEach(n => walk(n, 0));
  state.nodes.filter(n => !seen.has(n.id)).sort(sortByRank).forEach(n => walk(n, 0));
  return out;
}

/* ---------------- Identifiers ---------------- */
function nextNodeId(level, parentId) {
  if (level === 'L1') {
    let i = state.nodes.filter(n => n.level === 'L1').length + 1;
    let id = 'APP-' + i;
    while (INDEX.has(id)) { i += 1; id = 'APP-' + i; }
    return id;
  }
  const p = INDEX.get(parentId);
  if (!p) return '';
  let max = 0;
  childrenOf(parentId).forEach(c => {
    const tail = c.nodeId.split('-').pop();
    const num = parseInt(tail, 10);
    if (!isNaN(num)) max = Math.max(max, num);
  });
  let i = max + 1;
  let id = p.nodeId + '-' + i;
  while (INDEX.has(id)) { i += 1; id = p.nodeId + '-' + i; }
  return id;
}

function nextRank(level, parentId) {
  const step = { L2: 1000000, L3: 1000, L4: 1 }[level];
  if (level === 'L1') {
    const ranks = state.nodes.filter(n => n.level === 'L1' && n.rankId).map(n => n.rankId);
    return ranks.length ? Math.max.apply(null, ranks) + 1000000000 : 1000000000;
  }
  const p = INDEX.get(parentId);
  if (!p) return null;
  const siblingRanks = childrenOf(parentId).map(n => n.rankId).filter(r => r != null);
  let base = siblingRanks.length ? Math.max.apply(null, siblingRanks) : (p.rankId || 0);
  if (!base) {
    const ranks = state.nodes.filter(n => n.level === level && n.rankId).map(n => n.rankId);
    base = ranks.length ? Math.max.apply(null, ranks) : 1000000000;
  }
  const used = new Set(state.nodes.map(n => n.rankId).filter(r => r != null));
  let rank = base + step;
  while (used.has(rank)) rank += step;
  return rank;
}
